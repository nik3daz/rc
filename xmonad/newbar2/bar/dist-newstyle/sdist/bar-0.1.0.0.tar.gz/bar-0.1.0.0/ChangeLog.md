# Revision history for bar

## 0.2.0.0  -- 2019-05-28

* Second version of bar with cabal build system.
